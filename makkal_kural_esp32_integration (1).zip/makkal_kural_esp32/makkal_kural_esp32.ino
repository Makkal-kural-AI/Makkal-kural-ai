/*
 * Makkal Kural AI - ESP32 voice complaint device
 *
 * Board : "ESP32 Dev Module"   (an Arduino UNO has no WiFi / I2S and cannot run this)
 * Libs  : U8g2 (by olikraus). Nothing else to install.
 * Core  : arduino-esp32 2.0.x recommended (uses the legacy driver/i2s.h API)
 *
 * Wiring
 *   INMP441 mic : WS=15  SCK=14  SD=32  L/R=GND  VDD=3.3V  GND=GND
 *   MAX98357A   : BCLK=26  LRC=25  DIN=27  VIN=5V  GND=GND   (SD pin: leave unconnected)
 *   OLED SSD1306: SDA=21  SCL=22  VCC=3.3V  GND=GND
 *   Button      : GPIO4 -> GND (internal pull-up)
 *
 * NOTE: the amplifier DIN moved from GPIO22 to GPIO27 because GPIO22 is the
 *       OLED's I2C clock line.
 *
 * What it does: press button -> records 5 s -> streams it to the server as a
 * WAV (no big RAM buffer) -> server transcribes, saves to Supabase -> server
 * answers with a spoken confirmation which is played on the speaker.
 */

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <U8g2lib.h>
#include <driver/i2s.h>
#include "secrets.h"   // must define WIFI_SSID, WIFI_PASSWORD, DEVICE_TOKEN

// ---------- Settings you may change ----------
#define SERVER_HOST      "makkal-kural-api.onrender.com"  // the NEW API service, not the Streamlit one
#define SERVER_PORT      443
#define DEVICE_LOCATION  "Village Office"                 // ASCII only; saved with every complaint
#define RECORD_SECONDS   5
#define MIC_GAIN_SHIFT   14     // lower = louder mic (try 13 or 12 if recordings are too quiet)
#define PLAY_VOLUME_PCT  70     // 0-100
// ---------------------------------------------

#define BUTTON_PIN    4
#define SAMPLE_RATE   16000

#define I2S_MIC_WS    15
#define I2S_MIC_SD    32
#define I2S_MIC_SCK   14
#define I2S_AMP_BCLK  26
#define I2S_AMP_LRC   25
#define I2S_AMP_DIN   27

// Two separate I2S peripherals: mic on 0, speaker on 1.
static const i2s_port_t MIC_PORT = I2S_NUM_0;
static const i2s_port_t AMP_PORT = I2S_NUM_1;

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

uint32_t lastServerWake = 0;   // millis() of last successful /health ping (0 = never)

// ---------------------------------------------------------------- display
void show(const char *l1, const char *l2 = "", const char *l3 = "") {
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_ncenB08_tr);
  u8g2.drawStr(0, 14, l1);
  u8g2.setFont(u8g2_font_6x10_tr);
  u8g2.drawStr(0, 36, l2);
  u8g2.drawStr(0, 52, l3);
  u8g2.sendBuffer();
}

void showHome() { show("MAKKAL KURAL AI", "Press button to speak", "Your Voice-Our Priority"); }

// ---------------------------------------------------------------- I2S
void setupMic() {
  const i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,   // INMP441 sends 24-bit data in a 32-bit slot
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };
  const i2s_pin_config_t pins = {
    .bck_io_num = I2S_MIC_SCK,
    .ws_io_num = I2S_MIC_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = I2S_MIC_SD
  };
  i2s_driver_install(MIC_PORT, &cfg, 0, NULL);
  i2s_set_pin(MIC_PORT, &pins);
}

void setupAmp() {
  const i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,   // we send each sample twice (L+R)
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };
  const i2s_pin_config_t pins = {
    .bck_io_num = I2S_AMP_BCLK,
    .ws_io_num = I2S_AMP_LRC,
    .data_out_num = I2S_AMP_DIN,
    .data_in_num = I2S_PIN_NO_CHANGE
  };
  i2s_driver_install(AMP_PORT, &cfg, 0, NULL);
  i2s_set_pin(AMP_PORT, &pins);
}

// ---------------------------------------------------------------- network
void connectWiFi() {
  show("Connecting WiFi...", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) {
    delay(250);
    Serial.print('.');
  }
  Serial.println(WiFi.status() == WL_CONNECTED ? "\nWiFi connected" : "\nWiFi failed");
}

// Render's free tier sleeps when idle; a /health ping wakes it (can take ~1 min).
bool wakeServer() {
  show("Waking server...", "First time can take", "up to a minute");
  WiFiClientSecure client;
  client.setInsecure();               // prototype: skips certificate check
  HTTPClient http;
  http.setTimeout(60000);
  if (!http.begin(client, String("https://") + SERVER_HOST + "/health")) return false;
  int code = http.GET();
  http.end();
  Serial.printf("health -> %d\n", code);
  if (code == 200) { lastServerWake = millis(); if (lastServerWake == 0) lastServerWake = 1; }
  return code == 200;
}

String readLine(WiFiClientSecure &c, uint32_t deadline) {
  String s;
  while (millis() < deadline) {
    if (c.available()) {
      char ch = c.read();
      if (ch == '\n') return s;
      if (ch != '\r') s += ch;
    } else if (!c.connected()) {
      break;
    } else {
      delay(1);
    }
  }
  return s;
}

String headerValue(const String &line) {
  int i = line.indexOf(':');
  String v = (i < 0) ? "" : line.substring(i + 1);
  v.trim();
  return v;
}

// Reads response body bytes, handling both Content-Length and chunked encoding.
struct Body {
  bool chunked = false;
  long remaining = -1;   // -1 = unknown (read until the server closes)
  bool done = false;
};

int bodyRead(WiFiClientSecure &c, Body &b, uint8_t *buf, size_t want, uint32_t deadline) {
  if (b.done) return 0;
  if (b.chunked && b.remaining == 0) {
    String line = readLine(c, deadline);
    if (line.length() == 0) line = readLine(c, deadline);   // blank line after previous chunk
    b.remaining = strtol(line.c_str(), NULL, 16);
    if (b.remaining <= 0) { b.done = true; return 0; }
  }
  if (b.remaining >= 0 && (size_t)b.remaining < want) want = b.remaining;
  if (want == 0) { b.done = true; return 0; }
  while (!c.available()) {
    if (!c.connected() || millis() > deadline) { b.done = true; return 0; }
    delay(1);
  }
  int n = c.read(buf, want);
  if (n <= 0) { b.done = true; return 0; }
  if (b.remaining >= 0) {
    b.remaining -= n;
    if (!b.chunked && b.remaining == 0) b.done = true;
  }
  return n;
}

// ---------------------------------------------------------------- audio helpers
static void put32(uint8_t *p, uint32_t v) { p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24; }
static void put16(uint8_t *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }

void makeWavHeader(uint8_t *h, uint32_t dataBytes) {
  memcpy(h, "RIFF", 4);          put32(h + 4, 36 + dataBytes);
  memcpy(h + 8, "WAVEfmt ", 8);  put32(h + 16, 16);
  put16(h + 20, 1);              put16(h + 22, 1);                // PCM, mono
  put32(h + 24, SAMPLE_RATE);    put32(h + 28, SAMPLE_RATE * 2);
  put16(h + 32, 2);              put16(h + 34, 16);
  memcpy(h + 36, "data", 4);     put32(h + 40, dataBytes);
}

// Play raw 16-bit mono PCM (16 kHz) arriving over the socket.
void playResponse(WiFiClientSecure &c, Body &b, uint32_t deadline) {
  uint8_t in[1024];
  int16_t out[1024];              // 512 samples x 2 channels
  int have = 0;
  while (true) {
    int n = bodyRead(c, b, in + have, sizeof(in) - have, deadline);
    if (n <= 0) break;
    have += n;
    int usable = have & ~1;       // whole 16-bit samples only
    int samples = usable / 2;
    for (int i = 0; i < samples; i++) {
      int32_t v = (int16_t)(in[2 * i] | (in[2 * i + 1] << 8));
      v = v * PLAY_VOLUME_PCT / 100;
      out[2 * i] = out[2 * i + 1] = (int16_t)v;
    }
    size_t written = 0;
    i2s_write(AMP_PORT, out, samples * 4, &written, portMAX_DELAY);
    if (have != usable) in[0] = in[usable];   // keep a dangling odd byte
    have -= usable;
  }
  i2s_zero_dma_buffer(AMP_PORT);
}

// ---------------------------------------------------------------- main action
void runComplaint() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
    if (WiFi.status() != WL_CONNECTED) { show("No WiFi", "Check hotspot/router"); delay(2500); return; }
  }
  if (lastServerWake == 0 || millis() - lastServerWake > 10UL * 60UL * 1000UL) {
    if (!wakeServer()) { show("Server not reachable", "Try again later"); delay(2500); return; }
  }

  show("Connecting...");
  WiFiClientSecure client;
  client.setInsecure();
  if (!client.connect(SERVER_HOST, SERVER_PORT)) {
    show("Cannot connect", "to server"); delay(2500); return;
  }

  const uint32_t dataBytes = (uint32_t)SAMPLE_RATE * 2 * RECORD_SECONDS;
  client.printf(
    "POST /upload_audio HTTP/1.1\r\nHost: %s\r\nContent-Type: audio/wav\r\n"
    "Content-Length: %lu\r\nX-Device-Token: %s\r\nX-Location: %s\r\n"
    "Connection: close\r\n\r\n",
    SERVER_HOST, (unsigned long)(44 + dataBytes), DEVICE_TOKEN, DEVICE_LOCATION);

  uint8_t wav[44];
  makeWavHeader(wav, dataBytes);
  client.write(wav, 44);

  // ---- record and stream straight to the socket (no large RAM buffer) ----
  Serial.println("Recording...");
  int32_t raw[256];
  int16_t pcm[256];
  uint32_t sent = 0, t0 = millis(), lastShown = 99;
  bool ok = true;
  while (sent < dataBytes) {
    if (millis() - t0 > (RECORD_SECONDS + 3) * 1000UL) { ok = false; Serial.println("mic timeout"); break; }
    uint32_t left = RECORD_SECONDS - (millis() - t0) / 1000;
    if (left != lastShown && left <= RECORD_SECONDS) {
      lastShown = left;
      char buf[24];
      snprintf(buf, sizeof(buf), "Speak now... %lus", (unsigned long)left);
      show("Listening", buf, "Pesungal / Speak");
    }
    size_t br = 0;
    i2s_read(MIC_PORT, raw, sizeof(raw), &br, 200 / portTICK_PERIOD_MS);
    int n = br / 4;
    if (n == 0) continue;
    uint32_t maxN = (dataBytes - sent) / 2;
    if ((uint32_t)n > maxN) n = maxN;
    for (int i = 0; i < n; i++) {
      int32_t s = raw[i] >> MIC_GAIN_SHIFT;
      if (s > 32767) s = 32767;
      if (s < -32768) s = -32768;
      pcm[i] = (int16_t)s;
    }
    if (client.write((uint8_t *)pcm, n * 2) != (size_t)(n * 2)) { ok = false; Serial.println("send failed"); break; }
    sent += n * 2;
  }
  if (!ok) { client.stop(); show("Recording failed", "Check mic wiring"); delay(2500); return; }

  show("Processing AI...", "Please wait");
  Serial.println("Waiting for response...");

  // ---- read response ----
  uint32_t deadline = millis() + 90000UL;      // Whisper on a free CPU can be slow
  String statusLine = readLine(client, deadline);
  int status = statusLine.length() >= 12 ? statusLine.substring(9, 12).toInt() : 0;
  Serial.println(statusLine);

  Body body;
  String trackingId, category, message;
  while (true) {
    String line = readLine(client, deadline);
    if (line.length() == 0) break;            // blank line = end of headers
    String low = line; low.toLowerCase();
    if (low.startsWith("content-length:")) body.remaining = headerValue(line).toInt();
    else if (low.startsWith("transfer-encoding:") && low.indexOf("chunked") >= 0) { body.chunked = true; body.remaining = 0; }
    else if (low.startsWith("x-tracking-id:")) trackingId = headerValue(line);
    else if (low.startsWith("x-category:"))    category = headerValue(line);
    else if (low.startsWith("x-message:"))     message = headerValue(line);
  }

  if (status == 200) {
    Serial.printf("Saved %s (%s)\n", trackingId.c_str(), category.c_str());
    show("Complaint Saved!", trackingId.c_str(), category.c_str());
    playResponse(client, body, deadline);
  } else {
    Serial.printf("Server error %d: %s\n", status, message.c_str());
    char buf[24];
    snprintf(buf, sizeof(buf), "Error %d", status);
    if (status == 422) show("Try again", message.c_str(), "Speak louder/closer");
    else show(buf, message.c_str());
  }
  client.stop();
  delay(2500);
}

// ---------------------------------------------------------------- Arduino
void setup() {
  Serial.begin(115200);
  delay(500);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  u8g2.begin();
  setupMic();
  setupAmp();
  connectWiFi();
  if (WiFi.status() == WL_CONNECTED) wakeServer();
  showHome();
}

void loop() {
  if (digitalRead(BUTTON_PIN) == LOW) {
    delay(40);
    if (digitalRead(BUTTON_PIN) == LOW) {
      runComplaint();
      while (digitalRead(BUTTON_PIN) == LOW) delay(10);   // wait for release
      showHome();
    }
  }
  delay(10);
}
